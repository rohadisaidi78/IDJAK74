myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))
#Accessing List by Position
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])
#Changing Value in a list
myFruitList[1] = "orange"
print(myFruitList)
#Tuple Data Type
myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))
#Accessing Tuple by position
print(myFinalAnswerTuple[0])
print(myFinalAnswerTuple[1])
print(myFinalAnswerTuple[2])
#Dictionary Data Type
myFavoriteFruitDictionary = {
    "Akua" : "apple",
    "Saanvi" : "banana",
    "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))
#accessing dictionary by name
print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])