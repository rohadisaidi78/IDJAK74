#Hello World
print("Hello, Learners")
print("Welcome to AWS re/Start programm IDJAK74")
